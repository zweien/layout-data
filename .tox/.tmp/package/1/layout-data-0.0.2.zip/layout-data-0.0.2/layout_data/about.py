# -*- encoding: utf-8 -*-
"""
Desc      :   About layout-data.
"""
# File    :   about.py
# Time    :   2020/04/07 08:13:23
# Author  :   Zweien
# Contact :   278954153@qq.com

__version__ = "0.0.2"
__author__ = "Zweien"
__licence__ = "MIT"
__desp__ = "Layout dataset package."
